import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';

const app = express();
app.use(cors());
app.use(express.json());

const SECRET = 'secreto123';

app.post('/api/login', (req, res) => {
  const { usuario, clave } = req.body;
  if (usuario === 'admin' && clave === '1234') {
    const token = jwt.sign({ usuario }, SECRET, { expiresIn: '1h' });
    res.json({ token });
  } else {
    res.status(401).json({ error: 'Credenciales inválidas' });
  }
});

app.get('/api/privado', (req, res) => {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: 'No autorizado' });

  const token = auth.split(' ')[1];
  try {
    const datos = jwt.verify(token, SECRET);
    res.json({ mensaje: `Hola ${datos.usuario}, accediste a contenido protegido.` });
  } catch {
    res.status(403).json({ error: 'Token inválido' });
  }
});

app.listen(3000, () => console.log('API escuchando en http://localhost:3000'));
